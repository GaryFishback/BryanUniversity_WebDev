//index.js

import React from 'react'


//function components
function Navbar() {
  return (
    <div>
        
    </div>
  )
}

export default Navbar