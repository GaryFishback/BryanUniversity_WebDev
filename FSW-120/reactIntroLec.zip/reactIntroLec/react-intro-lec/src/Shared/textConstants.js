export const landingText = {
    home1: 'Here is our example image'
}
