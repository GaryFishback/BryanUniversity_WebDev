//what is an object .... what objects have we seen containing data while getting things from an API

//a method is a function set as a property of an object that enacts itself UPON the object itself
export default {
    data: {

    }
    //have some push/pop methods to add/ and delte stuff
}

