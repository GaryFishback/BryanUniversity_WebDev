//index.js
import React from 'react'

import List from '../Tweets/List/index'

function Landing() {
  return (
    <div>
      <List />
    </div>
  )
}

export default Landing;
