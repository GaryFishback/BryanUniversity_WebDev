//index.js

import React from 'react'


//function components
function Footer() {
  return (
    <div>
        
    </div>
  )
}

export default Footer;