//index.js

import React from 'react'


//function components
function Blog() {
  return (
    <div>
        Blog test
    </div>
  )
}

export default Blog
