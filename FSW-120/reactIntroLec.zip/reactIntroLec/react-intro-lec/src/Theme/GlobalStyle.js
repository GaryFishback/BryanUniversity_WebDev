//GlobalStyle.js

import { createGlobalStyle } from 'styled-components'

const GlobStyle = createGlobalStyle`
    a {
        
    }
`

export default GlobStyle