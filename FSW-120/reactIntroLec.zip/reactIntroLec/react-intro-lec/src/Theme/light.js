export default {
    colors: {
      mainDark: '222B30',
      background: '#f2deb3'
    }
  }